<?php
/**
 * @author zeng
 * time:2012-3-30
 * QQ:1077040796
 * 
 */
define('CHAT', true);
include dirname(__FILE__).'/include/commen.inc.php';
global $system,$mysql;
$my_global=new myGlobal();
if (!isset($_COOKIE['username'])) {
		$my_global->_unset_cookies();
		$my_global->_location('非法操作，请正常登陆！！！','index.php');
}
if (!$row=$mysql->_fetch_array("select mc_id from mc_user where mc_username='{$_COOKIE['username']}' limit 1 ")) {
		$my_global->_unset_cookies();
		$my_global->_location('非法操作，请正常登陆！！！','index.php');
}

if (isset($_GET['action'])&&(($_GET['action']=='read')||($_GET['action']=='witer')||($_GET['action']=='load'))) {
	//文件创建
	$file_read_time=time()-4;
	if (!file_exists($system['data_dir'])) {
		mkdir($system['data_dir'],0777);
	};
	if (!file_exists($system['online_file'])) {
		file_put_contents($system['online_file'], '');
	};
	if (!file_exists($system['record'])) {
		file_put_contents($system['record'], '');
		$str_start='20:51:12§★ξ☆§系统§★ξ☆§欢迎进入聊天室|-ξ§ξ-|'."\n";
		$my_global->_file_witer($str_start, $system['record']);
		
	};
	$key=array('time','user','content');
	//第一次加载数据
	if ($_GET['action']=='load') {
		$read=$my_global->_file_fread($system['record']);
		if(empty($read)){
			echo 4;
			exit(0);
		}
		$read=explode('|-ξ§ξ-|', $read);
		for ($i = 0; $i < count($read)-1; $i++) {
			$send[$i]=explode('§★ξ☆§', $read[$i]);
			$send[$i]=array_combine($key, $send[$i]);
		}
		echo json_encode($send);
		exit(0);
	}
	//写数据
	if ($_GET['action']=='witer') {
		$clean=array();
		$clean['user']=$_POST['user'];
		$clean['content']=$my_global->_content_check($_POST['content'], 'doc/mgchar.txt',0);
		$clean['date']=trim($_POST['time']);
		$clean['all']=$clean['date'].'§★ξ☆§'.$clean['user'].'§★ξ☆§'.$clean['content'].'|-ξ§ξ-|'."\n";
		$my_global->_file_witer($clean['all'], $system['record']);
	}
	//读数据
	//判断数据是否有更新
	
	$file_change_time=filemtime($system['record']);
	if ($file_read_time>=$file_change_time) {
		echo 5;
		exit(0);
	}
	
	$read=$my_global->_file_fread($system['record']);
	if(empty($read)){
		echo 4;
		exit(0);
	}

	$last_accept=array();
	$last_accept['user']=$_POST['lastuser'];
	$last_accept['lastdate']=trim($_POST['lastdate']);
	$time_last=explode(':', $last_accept['lastdate']);
	$time_last_str=mktime($time_last[0],$time_last[1],$time_last[2]);
	
	$read=explode('|-ξ§ξ-|', $read);
	$j=0;
	$lock=0;
	for ($i = 0; $i < count($read)-1; $i++) {
		$send[$i]=explode('§★ξ☆§', $read[$i]);
		$time_ago=explode(':', trim($send[$i][0]));
		$time_ago_str=mktime($time_ago[0],$time_ago[1],$time_ago[2]);

		if ($lock==1) {
			$last_send[$j]=$send[$i];
			$last_send[$j]=array_combine($key, $last_send[$j]);
			$j++;
		}
		if ($time_ago_str==$time_last_str&&$last_accept['user']==$send[$i][1]) {
			$lock=1;
			if ($i==count($read)-2) {
				echo 5;
				exit(0);
			}
		}

	}

	
	echo json_encode($last_send);
	exit(0);
}

if (isset($_GET['action'])&&$_GET['action']=='info') {
	$file_online_read_time=time()-3;		
	$j=0;
	if (filesize($system['online_file'])==0) {
		echo 5;
	}																	//online文件上一次读取的时间
	if ($file_online_read_time>filemtime($system['online_file'])) {							//文件修改时间和读时间比较，大于则无更新，不读；小于则有更新，读。
		echo 5;
		exit(0);
	}
	$keny_login=array('time','type','name','user','face');
	$login_info_read=$my_global->_file_fread($system['online_file']);
	$login_info_read_even=explode('|-ξ§ξ-|',$login_info_read);
	for ($i = count($login_info_read_even)-2; $i >=0; $i--) {
		$login_info_even[$j]=explode('§★ξ☆§', $login_info_read_even[$i]);
		$last_send[$j]=array_combine($keny_login, $login_info_even[$j]);
		$j++;
		if ($j==20) {
			break;
		}
		
	}
	if (empty($last_send)) {
		echo 5;
		exit(0);
	}
	echo json_encode($last_send);
	
	
	
	
	
	exit(0);
}
 ?>