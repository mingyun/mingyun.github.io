-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 05 月 28 日 10:21
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `webchat`
--

-- --------------------------------------------------------

--
-- 表的结构 `mc_user`
--

CREATE TABLE IF NOT EXISTS `mc_user` (
  `mc_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `mc_username` varchar(40) NOT NULL,
  `mc_minname` varchar(20) DEFAULT NULL,
  `mc_pwd` char(40) NOT NULL,
  `mc_face` varchar(100) NOT NULL,
  `mc_email` varchar(100) DEFAULT NULL,
  `mc_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mc_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mc_noread` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `mc_noread_time` datetime NOT NULL,
  `mc_reg_time` datetime NOT NULL,
  `mc_reg_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`mc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `mc_user`
--

INSERT INTO `mc_user` (`mc_id`, `mc_username`, `mc_minname`, `mc_pwd`, `mc_face`, `mc_email`, `mc_level`, `mc_state`, `mc_noread`, `mc_noread_time`, `mc_reg_time`, `mc_reg_ip`) VALUES
(1, 'admin', 'admin', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', 'face/1.JPG', NULL, 2, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '127.0.0.1'),
(2, '520417', '520417', '3d4f2bf07dc1be38b20cd6e46949a1071f9d0e3d', 'face/1.JPG', '542432195@qq.com', 0, 0, 0, '0000-00-00 00:00:00', '2012-03-28 14:40:06', '127.0.0.1');