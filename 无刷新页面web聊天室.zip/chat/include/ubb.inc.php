<?php 
/**
 * @author zeng
 * time:2012-2-7
 * QQ:1077040796
 * 
 */

	if (!defined('CHAT')) {
		$my_global->_location('error', 'index.php');
	}
	
?>
			<div id="ubb" >
				<img id="font_size" src="image/fontsize.gif" alt="字体大小"  title="字体大小"/>
				<input type="text"  class="text" name="font_size" readonly="readonly" value="14"/>
				<img id="font_color" src="image/color.gif" alt="字体颜色"  title="字体颜色"/>
				<input type="text"  class="text" name="font_color" readonly="readonly" value="#000"/>
				<img id="piz" src="image/piz.gif" alt="表情"  title="表情"/>
				<img src="image/space.gif" />
				<img class="family" src="image/bold.gif" title="粗体" id="bold"/>
				<img class="family" src="image/italic.gif" title="斜体"  id="italic"/>
				<img class="family" src="image/underline.gif" title="下划线" id="underline"/>
				<img class="family" src="image/strikethrough.gif" title="删除线"  id="line-through"/>
				<input type="button" id="send" value="发送"/>
			</div>
			<div id="font">
					<strong style="font-size:10px;" onclick="font(10)">10px</strong>
					<strong style="font-size:12px;" onclick="font(12)">12px</strong>
					<strong style="font-size:14px;" onclick="font(14)">14px</strong>
					<strong style="font-size:16px;" onclick="font(16)">16px</strong>
					<strong style="font-size:18px;" onclick="font(18)">18px</strong>
					<strong style="font-size:20px;" onclick="font(20)">20px</strong>
					<strong style="font-size:22px;" onclick="font(22)">22px</strong>
					<strong style="font-size:24px;" onclick="font(24)">24px</strong>
					<strong style="font-size:30px;" onclick="font(30)">30px</strong>
			</div>
			<div id="color">
					<strong title="黑色" style="background:#000" onclick="showcolor('#000')"></strong>
					<strong title="褐色" style="background:#930" onclick="showcolor('#930')"></strong>
					<strong title="橄榄树" style="background:#330" onclick="showcolor('#330')"></strong>
					<strong title="深绿" style="background:#030" onclick="showcolor('#030')"></strong>
					<strong title="深青" style="background:#036" onclick="showcolor('#036')"></strong>
					<strong title="深蓝" style="background:#000080" onclick="showcolor('#000080')"></strong>
					<strong title="靓蓝" style="background:#339" onclick="showcolor('#339')"></strong>
					<strong title="灰色-80%" style="background:#333" onclick="showcolor('#333')"></strong>
					<strong title="深红" style="background:#800000" onclick="showcolor('#800000')"></strong>
					<strong title="橙红" style="background:#f60" onclick="showcolor('#f60')"></strong>
					<strong title="深黄" style="background:#808000" onclick="showcolor('#000')"></strong>
					<strong title="深绿" style="background:#008000" onclick="showcolor('#808000')"></strong>
					<strong title="绿色" style="background:#008080" onclick="showcolor('#008080')"></strong>
					<strong title="蓝色" style="background:#00f" onclick="showcolor('#00f')"></strong>
					<strong title="蓝灰" style="background:#669" onclick="showcolor('#669')"></strong>
					<strong title="灰色-50%" style="background:#808080" onclick="showcolor('#808080')"></strong>
					<strong title="红色" style="background:#f00" onclick="showcolor('#f00')"></strong>
					<strong title="浅橙" style="background:#f90" onclick="showcolor('#f90')"></strong>
					<strong title="酸橙" style="background:#9c0" onclick="showcolor('#9c0')"></strong>
					<strong title="海绿" style="background:#396" onclick="showcolor('#396')"></strong>
					<strong title="水绿色" style="background:#3cc" onclick="showcolor('#3cc')"></strong>
					<strong title="浅蓝" style="background:#36f" onclick="showcolor('#36f')"></strong>
					<strong title="紫罗兰" style="background:#800080" onclick="showcolor('#800080')"></strong>
					<strong title="灰色-40%" style="background:#999" onclick="showcolor('#999')"></strong>
					<strong title="粉红" style="background:#f0f" onclick="showcolor('#f0f')"></strong>
					<strong title="金色" style="background:#fc0" onclick="showcolor('#fc0')"></strong>
					<strong title="黄色" style="background:#ff0" onclick="showcolor('#ff0')"></strong>
					<strong title="鲜绿" style="background:#0f0" onclick="showcolor('#0f0')"></strong>
					<strong title="青绿" style="background:#0ff" onclick="showcolor('#0ff')"></strong>
					<strong title="天蓝" style="background:#0cf" onclick="showcolor('#0cf')"></strong>
					<strong title="梅红" style="background:#936" onclick="showcolor('#936')"></strong>
					<strong title="灰度-20%" style="background:#c0c0c0" onclick="showcolor('#c0c0c0')"></strong>
					<strong title="玫瑰红" style="background:#f90" onclick="showcolor('#f90')"></strong>
					<strong title="茶色" style="background:#fc9" onclick="showcolor('#fc9')"></strong>
					<strong title="浅黄" style="background:#ff9" onclick="showcolor('#ff9')"></strong>
					<strong title="浅绿" style="background:#cfc" onclick="showcolor('#cfc')"></strong>
					<strong title="浅青绿" style="background:#cff" onclick="showcolor('#cff')"></strong>
					<strong title="浅蓝" style="background:#9cf" onclick="showcolor('#9cf')"></strong>
					<strong title="淡紫" style="background:#c9f" onclick="showcolor('#c9f')"></strong>
					<strong title="白色" style="background:#fff" onclick="showcolor('#fff')"></strong>
				</div>
				<div id="div_piz">
					<ul>
						<li><a href="#piz-1">1</a></li>
					</ul>
						<div id="piz-1" class="pizs_num">
						<?php 
							for ($i = 0; $i < 55; $i++) {
								echo "<img src='qpic/1/".$i.".gif' title='".$i."'/>";
							}
						?>
						</div>
						<div id="piz-2" class="pizs_num">
						</div>
						<div id="piz-3" class="pizs_num">
						</div>
				</div>