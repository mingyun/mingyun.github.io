<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
 if (!defined('CHAT')) {
 	echo "非法调用！！！";
 	exit(0);
 }
 	
 
 ?>
<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.18.custom.min.js"></script>
<script type="text/javascript"  src="js/chat.js"></script>
<link rel="stylesheet"  type="text/css"  href="css/smoothness/jquery-ui-1.8.18.custom.css" />
<link rel="stylesheet"  type="text/css"  href="css/chat.css" />