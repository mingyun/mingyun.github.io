<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
 class myMysql extends myGlobal{
 	private $host;
 	private $name;
 	private $pass;
 	private $table;
 	private $ut;
 	
      function __construct($host,$name,$pass,$table,$ut='utf8'){
     	$this->host=$host;
     	$this->name=$name;
     	$this->pass=$pass;
     	$this->table=$table;
     	$this->ut=$ut;
     	$this->_connect();

     }
     
     function _connect(){
     	$link=mysql_connect($this->host,$this->name,$this->pass) or die ($this->error());
     	mysql_select_db($this->table,$link) or die("没该数据库：".$this->table);
     	mysql_query("SET NAMES $this->ut");
     }
     
  	function _query($sql) {
 		if (!$result=mysql_query($sql)) {
 			exit('sql语句执行失败'.mysql_error());
 		}
 		return $result;
 	}
 	
 	/**
 	 * 结果集数据提取函数
 	 * @param $sql
 	 */
 	function _fetch_array($sql) {
 		return mysql_fetch_array( self::_query($sql),MYSQL_ASSOC);
 	}
 	
 	/**
 	 *
 	 * Enter description here ...
 	 * @param $result
 	 */
 	function _fetch_array_list($result) {
 		return mysql_fetch_array($result,MYSQL_ASSOC);
 	}
 	
 	/**
 	 * 返回影响的行数
 	 * Enter description here ...
 	 */
 	function _affected_rows() {
 		return mysql_affected_rows();
 	}
 	
 	/**
 	 * 用户名重复验证函数
 	 * Enter description here ...
 	 * @param $sql
 	 * @param $info
 	 */
 	function _repeat($sql,$info) {
 		if(self::_fetch_array($sql)){
 			parent::_alert($info);
 		}
 	}
 	
 	/**
 	 * 销毁结果集
 	 * Enter description here ...
 	 * @param $result
 	 */
 	function _free_result($result) {
 		mysql_free_result($result);
 	}
 	/**
 	 * 数据库关闭函数
 	 * Enter description here ...
 	 */
 	function _close(){
 		mysql_close();
 	}
     
 	function __destruct(){
 		
 	}
 }
 	
 
 ?>