<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
 class myGlobal {
 	function __construct() {
 		;
 	}
 	/**
 	 * 弹窗函数：
 	 * 验证弹窗
 	 * @param $info 要提醒的信息输出
 	 */
 	function _alert($info) {
 		echo "<script type='text/javascript'>
 		alert('".$info."');
 		history.back();
 		</script>";
 		exit();
 	}
 	
 	/**
 	 * 跳转函数：
 	 * 调到指定页面
 	 * @param $info
 	 * @param $url
 	 */
 	function _location($info,$url) {
 		if(!empty($info)){
 			echo "<script type='text/javascript'>
 			alert('".$info."');
 			location.href='$url';
 			</script>";
 			exit();
 		}else{
 		header('Location:'.$url);
 		}
 		}
 	
 		/**
 		* 自动关窗口函数
 		 * Enter description here ...
 		 * @param $info
 		 */
 		 function _alert_close($info) {
 			echo "<script type='text/javascript'>
 			alert('".$info."');
 			window.close();
 			</script>";
 			exit();
 		}
 		/**
 		 * 字符转意函数
 		 * Enter description here ...
 		 * @param $string
 		 */
 		function _mysql_string($string) {
 			if(!GPC){
 				if (is_array($string)) {
 					foreach ($string as $key => $value) {
 						$string[$key]=self::_mysql_string($value);
 					}
 				}else {
 					$string=mysql_real_escape_string($string);
 				}
 			}
 			return $string;
 		}
 		/**
 		 * html转义函数，可转义字符串与数组
 		 * Enter description here ...
 		 * @param $string
 		 */
 		function _html($string) {
 			if(is_array($string)){
 				foreach ($string as $_key => $_value) {
 					$string[$_key]=self::_html($_value);
 				}
 			}
 			else{
 				$string=htmlspecialchars($string);
 			}
 			return $string;
 		}
 		
 		/**
 		 * 文件夹创建函数
 		 * @param unknown_type $name 文件夹名
 		 * @param unknown_type $path 目录
 		 * @return string 返回文件夹地址
 		 */
 		function _mkdir($userid,$path) {
 			if (!is_dir($path)) {
 				mkdir($path,0777);
 			};
 			if (!is_dir($path.'/'.$userid)) {
 				mkdir($path.'/'.$userid,0777);
 			};
 			$path=$path.'/'.$userid.'/'.time();
 			if (!is_dir($path)) {
 				mkdir($path,0777);
 				return $path;
 			}
 		}
 		/**
 		 * 设置cookies
 		 * @param unknown_type $username
 		 * @param unknown_type $time
 		 */
 		function _set_cookies($username,$time) {
 			switch ($time) {
 				case '0':
 					setcookie('username',$username);
 					break;
 				case '1':
 					setcookie('username',$username,time()+86400);
 					break;
 				case '2':
 					setcookie('username',$username,time()+604800);
 					break;
 				case '3':
 					setcookie('username',$username,time()+2592000);
 					break;
 			}
 		}
 		
 		/**
 		 * 账号退出，清除cookie
 		 * Enter description here ...
 		 */
 		function _unset_cookies() {
 			setcookie('username','',time()-1000);
 		}
 		
 	/**
	 * 缩略图生成函数
	 * @param unknown_type $_filename 图像路径
	 * @param unknown_type $width	缩略图宽
	 * @param unknown_type $height 缩略图高
	 */
	function _create_little_image($_filename,$width,$height){
		//生成png标头文件
		header('Content-type: image/png');
		$_n = explode('.',$_filename);
		//获取文件信息，长和高
		list($_width, $_height) = getimagesize($_filename);
		//生成缩微的长和高
		$_new_width = $width ;
		$_new_height = $height ;
		//创建一个以0.3百分比新长度的画布
		$_new_image = imagecreatetruecolor($_new_width,$_new_height);
		//按照已有的图片创建一个画布
		switch ($_n[1]) {
			case 'jpg' : $_image = imagecreatefromjpeg($_filename);
			break;
			case 'png' : $_image = imagecreatefrompng($_filename);
			break;
			case 'gif' : $_image = imagecreatefromgif($_filename);
			break;
		}
		//将原图采集后重新复制到新图上，就缩略了
		imagecopyresampled($_new_image, $_image, 0, 0, 0, 0, $_new_width,$_new_height, $_width, $_height);
		switch ($_n[1]) {
			case 'jpg' : imagejpeg($_new_image);
			break;
			case 'png' : imagepng($_new_image);
			break;
			case 'gif' : imagegif($_new_image);
			break;
		}
		imagejpeg($_new_image);
		imagedestroy($_new_image);
		imagedestroy($_image);
	}
	
	/**
	 * 文件读取，返回数组
	 * @param unknown_type $path 路径
	 * @return multitype:
	 */
	function _file_read($path) {
		if (!file_exists($path)) {
			self::_alert('此文件不存在');
		};
		$mg_string=file($path);
		//print_r($mg_string);
		return $mg_string;
	}
	
	/**
	 * 输入内容检查
	 * @param unknown_type $param
	 * @param unknown_type $path
	 * @return string|mixed
	 */
	function _content_check($param,$path,$type) {
		$len=mb_strlen($param,'utf8');
		$mode=array();
		$replace=array('***');
		if ($len>500) {
			return '内容太多';
		}
		if ($type==1) {
			$mg_string=self::_file_read($path);
			echo $param=str_replace('江泽民', '***', $param);
			
		}
		/*  [bq_1 41/]   */
		//$param = preg_replace('/\[bq_1 (.*)\/\]/U','<img src="qpic/1/\\1.gif" />',$param);
		//$param = preg_replace("'/\[bq_1 (.*)/\]/", "<img src=\"qic/1\\2.gif\" />", $param);
		return $param;
	}
	
	/**
	 * 写
	 * @param unknown_type $content
	 * @param unknown_type $path
	 * @return boolean
	 */
	function _file_witer($content,$path) {
		if (!file_exists($path)) return false;
		$fp=@fopen($path,'a');
		flock($fp, LOCK_EX);
		$all=fwrite($fp,$content);
		fclose($fp);
		return true;
	}
	/**
	 * 读
	 * @param unknown_type $path
	 * @return NULL|string
	 */
	function _file_fread($path) {
		//global $file_read_time;
		$handle = fopen($path, "r");
		if(filesize ($path)==0){return null;}
		$contents = fread($handle, filesize ($path));
		fclose($handle);
		//echo $contents;
		//$file_read_time=time();
		return  $contents;
	}
	
	function _array_list_pos($array,$str) {
		$num=0;
		for ($i = count($array)-1; $i >=0; $i--) {
			foreach ($array[$i] as $key => $value) {
				if ($array[$i]['user']==$str) {
					$num++;
					if ($num==2) {
						return $i;
					}
				}
				
			}
		}
		return 0;
	}
	
	
 }
 ?>