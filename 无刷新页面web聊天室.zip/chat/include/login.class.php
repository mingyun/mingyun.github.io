<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */

 class myLogin extends myGlobal{
 	private $name;
 	private $pwd;

	public function getName() {
		return $this->name;
	}

	public function getPwd() {
		return $this->pwd;
	}

	public function setName($name) {
		$this->name = $name;
	}

	public function setPwd($pwd) {
		$this->pwd = $pwd;
	}
	function __construct($username,$password){
 		self::setName($username);
 		self::setPwd($password);
 	}
 	
 	function _name_check($str=null) {
 		$string=trim($str);
 		$min_len=1;
 		if ($str==null) {
 			$string=trim($this->name);
 			$min_len=5;
 		}
 		$len=mb_strlen($string,'utf-8');
 		if ($len<$min_len||$len>20) {
 			parent::_alert("用户名不能小于5位或大于20位");
 		}
 		//限制敏感字符
 		$mg_char='/[<>\'\"\ ]/';
 		if (preg_match($mg_char, $string)) {
 			parent::_alert('用户名中含有敏感字符');
 		}
 		//限制敏感姓名注册
 		$mg[0]='曾长付';
 		$mg[1]='毛泽东';
 		$mg[2]='邓小平';
 		$mg[3]='江泽民';
 		$mg[4]='胡锦涛';
 		if (in_array($string, $mg)) {
 			parent::_alert($string.'等敏感姓名不能注册');
 		}
 		 
 		return mysql_escape_string($string);
 	}
 	function _pwd_check() {
 		$len = strlen($this->pwd);
 		if ($len<5||$len>20) {
 			parent::_alert("密码不能小于5位或大于20位");
 		}
 		return sha1($this->pwd);
 	}
 	
 	function _login_check() {
 		$clean_login=array();
 		$clean_login['name']=$this->_name_check();
 		$clean_login['pwd']=$this->_pwd_check();
 		return $clean_login;
 	}
 	
  	/**
 	 * email验证函数：
 	 * 正则式匹配email，保持数据的规范
 	 * @param $string 提交的邮箱email
 	 * @param $_min_num
 	 * @param $_max_num
 	 */
 	function _email_check($string,$_max_num) {
 		//542432195@qq.com
 		$p_mode='/^([\w\-\.]{2,})@([\w\-]{2,})([\.\w]{1,})$/';
	 		if(!preg_match($p_mode, $string)){
	 			parent::_alert('邮箱格式不正确！');
	 		}
 			if (strlen($string) > $_max_num) {
				parent::_alert('邮件长度不合法！');
	}
 		return $string;
 	}
 	/**
 	 * 密码验证：
 	 * 两次密码输入验证
 	 * @param $f_pass 第一次密码输入
 	 * @param $s_pass	第二次密码输入
 	 * @param $min_len	限制密码最小长度
 	 * @return 经过sha1加密的40位字符串
 	 */
 	function _pwd_check_two($f_pass, $min_len){
 		$len=strlen($f_pass);
 		if($len<$min_len){
 			parent::_alert('密码不能小于'.$min_len.'位');
 		}
 		if ($f_pass!=$this->pwd) {
 			parent::_alert('两次密码输入不同，请重新输入');
 		}

 	}
 	
 	
 	
 	
 	
 	
 	function __destruct(){
 		
 	}
 }
 	
 
 ?>