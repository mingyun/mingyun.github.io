<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
//防恶意调用
if(!defined('CHAT')){
	exit('Sorry, undefined');
}
 	//数据可连接
 	define('DB_HOST', 'localhost');
 	define('DB_USER', 'root');
 	define('DB_PWD', '520417');
 	define('DB_NAME', 'webchat');
 	
 	global $system;
 	
 	$system=array();
 	$system['data_dir']='data/';
 	$system['online_file']=$system['data_dir'].date("Ymd").'-online.php';
 	$system['record']=$system['data_dir'].date("Ymd").'-record.php';

//字符编码
header('Content-Type: text/html; charset=utf-8');
//转换硬路径
define('ROOT_PATH',substr(dirname(__FILE__),0,-7));
//定义一个是否字符转义常量
define('GPC', get_magic_quotes_gpc());
require_once ROOT_PATH.'include/global.class.php';
require_once ROOT_PATH.'include/mysql.class.php';
require_once ROOT_PATH.'include/login.class.php';

$mysql = new myMysql(DB_HOST, DB_USER, DB_PWD, DB_NAME);

global $mysql;
 
 ?>