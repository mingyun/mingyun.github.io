<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
/**
	 * 缩略图生成函数
	 * @param unknown_type $_filename 图像路径
	 * @param unknown_type $width	缩略图宽
	 * @param unknown_type $height 缩略图高
	 */
	function _create_little_image($_filename,$width,$height){
		//生成png标头文件
		header('Content-type: image/png');
		$_n = explode('.',$_filename);
		//获取文件信息，长和高
		list($_width, $_height) = getimagesize($_filename);
		//生成缩微的长和高
		$_new_width = $width ;
		$_new_height = $height ;
		//创建一个以0.3百分比新长度的画布
		$_new_image = imagecreatetruecolor($_new_width,$_new_height);
		//按照已有的图片创建一个画布
		switch ($_n[1]) {
			case 'jpg' : $_image = imagecreatefromjpeg($_filename);
			break;
			case 'png' : $_image = imagecreatefrompng($_filename);
			break;
			case 'gif' : $_image = imagecreatefromgif($_filename);
			break;
		}
		//将原图采集后重新复制到新图上，就缩略了
		imagecopyresampled($_new_image, $_image, 0, 0, 0, 0, $_new_width,$_new_height, $_width, $_height);
		switch ($_n[1]) {
			case 'jpg' : imagejpeg($_new_image);
			break;
			case 'png' : imagepng($_new_image);
			break;
			case 'gif' : imagegif($_new_image);
			break;
		}
		imagejpeg($_new_image);
		imagedestroy($_new_image);
		imagedestroy($_image);
	}
if (isset($_GET['filename'])) {
	_create_little_image($_GET['filename'],20,20);
}
 ?>