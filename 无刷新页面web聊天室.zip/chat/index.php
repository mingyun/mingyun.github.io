<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
 	define('CHAT', true);
 	include dirname(__FILE__).'/include/commen.inc.php';
 	global $mysql,$system;
 	$my_global=new myGlobal();
 	/**
 	 * 登陆模块
 	 */
 	if (isset($_GET['action'])&&$_GET['action']=='login') {
 		if (!file_exists($system['online_file'])) {
 			file_put_contents($system['online_file'], '');
 		};
 		$clean=array();
 		$login=new myLogin($_POST['username'], $_POST['pwd']);
 		$clean=$login->_login_check();
 		$row=$mysql->_fetch_array("select mc_id,mc_pwd,mc_minname,mc_face from mc_user where mc_username='{$clean['name']}' limit 1");
 		if (!$row) {
 			$my_global->_alert('不好意思，没有此会员！！！');
 		}else{
 			if ($row['mc_pwd']==$clean['pwd']) {
 				$mysql->_query("update mc_user set mc_state=1 where mc_username='{$clean['name']}' limit 1");
 				$mysql->_close();
 				$my_global->_set_cookies($clean['name'], 1);
 				$login_time=date("H:i:s");
 				$login_info=$login_time."§★ξ☆§1§★ξ☆§".$row['mc_minname']."§★ξ☆§".$clean['name']."§★ξ☆§".$row['mc_face']."|-ξ§ξ-|\n";
 				$my_global->_file_witer($login_info, $system['online_file']);
 				$my_global->_location('登陆成功！！！', 'chat.php?id='.$row['mc_id']);
 				
 			}else{
 				$my_global->_alert('密码错误');
 			}
 			
 		}
 		
 	}
 	
 	/**
 	 * 注册模块
 	 */
 	if (isset($_GET['action'])&&$_GET['action']=='register') {
			$clean=array();
			$reg = new myLogin($_POST['reg_username'], $_POST['reg_pwd']);
			$reg->_pwd_check_two($_POST['reg_pwd2'], 5);
			$clean=$reg->_login_check();
			$mysql->_repeat("select mc_id from mc_user where mc_username='{$clean['name']}' limit 1", '已存在此会员');
			$clean['minname']=$reg->_name_check($_POST['name']);
			$clean['email']=$reg->_email_check($_POST['email'],50);
			$clean['face']=$_POST['face'];
			//print_r($clean);
			$mysql->_query("insert into mc_user(
														mc_username,
														mc_pwd,
														mc_minname,
														mc_face,
														mc_email,
														mc_reg_time,
														mc_reg_ip
																				)
																 values(
														'{$clean['name']}',
														'{$clean['pwd']}',
														'{$clean['minname']}',
														'{$clean['face']}',
														'{$clean['email']}',
														now(),
														'{$_SERVER['REMOTE_ADDR']}'
																				)");
			if ($mysql->_affected_rows()==1) {
				$mysql->_close();
				$reg->_location('注册成功', 'index.php');
			}else {
				$reg->_alert('注册失败！！！');
			}
			
	}
 
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	require ROOT_PATH.'include/header.inc.php'; 
?>
<title>webchat</title>
</head>
<body>

	<div id="main">
	<h2>登陆聊天室</h2>
	<form action="?action=login" method="post">
		<dl>
			<dd>账号：<input type="text" class="text" name="username" id="name"/> <a id="reg" href="javascript:;">注册</a></dd>
			<dd>密码：<input type="password" class="text"  name="pwd" id="pwd"/> <a href="#">忘记密码？</a></dd>
			<dd id="btu"><input type="submit" value="登陆" id="login"/> <input type="button" value="取消" id="reset"/></dd>
		</dl>
	</form>
	</div>
	
	<div id="register">
		<form action="?action=register" method="post">
		<dl>
			<dd>注册账号：<input type="text" class="text" name="reg_username" id="name"/></dd>
			<dd>注册昵称：<input type="text" class="text" name="name" id="name"/></dd>
			<dd><img id="head" title="头像" src="face/1.JPG"/></dd>
			<dd>注册密码：<input type="password" class="text"  name="reg_pwd" id="pwd"/> </dd>
			<dd>验证密码：<input type="password" class="text"  name="reg_pwd2" id="pwd2"/> </dd>
			<dd>注册邮箱：<input type="text" class="text"  name="email" id="email"/> </dd>
			<dd>选择头像：<input type="text" class="text"  name="face" id="headsrc" value="点击右边的小图选择头像" readonly="readonly"/> </dd>
			<dd id="btu"><input type="submit" value="注册" id="regbtu"/> <input type="button" value="取消" id="reset2"/></dd>
		</dl>
		<div id="faces">
		<dl>
			<?php
			for ($i = 1; $i < 48; $i++) {
		?>
		<dd><img class="title" title="头像"<?php echo $i.'.JPG'?> src="face/<?php echo $i.'.JPG'?>"/></dd>
		<?php }?>
		</dl>
		</div>
	</form>
	</div>
	
</body>
</html>
<?php 
	$mysql->_close();
?>