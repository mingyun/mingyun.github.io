$(document).ready(function(){
        $("#main").draggable();
        $("#chat_main").draggable({handle:"#title_h"}); ;
        $("#div_piz").tabs().draggable({handle:"ul"});
        
        $("#name").blur(function() {
            if($("#name").val().length<=0){
                $("#name").css("background","red");
            }else{
                $("#name").css("background","white");
            }
         });
        $("#pwd").blur(function() {
            if($("#pwd").val().length<=0){
                $("#pwd").css("background","red");
            }else{
                $("#pwd").css("background","white");
            }
         });
         $("#login").click(function() {
               if($("#name").val().length<5){
                    alert('用户名长度不能小于5');
                    return false;
                }else if($("#pwd").val().length<5){
                    alert('密码长度不能小于5');
                    return false;
            }
        });
        $("#reg").click(function() {
                $("#register").show(1000);
        });
        $("#reset2").click(function() {
                $("#register").hide(1000);
        });
        $("#register #head").click(function() {
            $("#faces").show();
            $(".title").click(function() {
                    $("#headsrc").val($(this).attr("src"));
                    $("#register #head").attr("src",$(this).attr("src"));
             });
        });
        $("#font_size").click(function() {
            $("#font").toggle();
        });
        $("#font_color").click(function() {
            $("#color").toggle();
        });
        $("#intext").css("font-size",$("input[name=font_size]").val());
        $("#intext").css("color",$("input[name=font_color]").val());
        
        $(".family").click(function() {
                $(this).toggleClass("checked");
                select_font(this);
        });
        $("#piz").click(function() {
            $("#div_piz").toggle();
        });
        $("#div_piz img").click(function() {
            $("#intext").append("<img src='"+$(this).attr('src')+"' title='[bq_1 "+$(this).attr('title')+"/]'/>");
            $("#div_piz").hide();
        });

   });
   

    function font(size) {
        $("input[name=font_size]").val(size);
        if(!$("#intext").hasClass('font_style')){
            $("#intext").addClass('font_style');
        }
        $(".font_style").css("font-size",size);
        $("#font").hide();
    }
    function showcolor(color) {
        $("input[name=font_color]").val(color);
        if(!$("#intext").hasClass('font_style')){
            $("#intext").addClass('font_style');
        }
        $(".font_style").css("color",color);
        $("#color").hide();
    }

    function select_font(font){
        if(!$("#intext").hasClass('font_style')){
            $("#intext").addClass('font_style');
        }
         var select_id = $(font).attr('id');
         if ($(font).hasClass('checked')) {
         switch(select_id){
             case 'bold':
                $(".font_style").css("font-weight",'bold');
                break;
             case 'italic':
                $(".font_style").css("font-style",'italic');
                break;
             case 'underline':
                $(".font_style").css("text-decoration",'underline');
                break;    
             case 'line-through':
             if ($(".font_style").css("text-decoration")=='underline') {
                 $(".font_style").css("text-decoration",$("#intext").css("text-decoration")+' line-through');
             } else{
                 $(".font_style").css("text-decoration",'line-through');
             };
                
                break;                      
         }

        } else{
          switch(select_id){
             case 'bold':
                $(".font_style").css("font-weight",'');
                break;
             case 'italic':
                $(".font_style").css("font-style",'');
                break;
             case 'underline':
                $(".font_style").css("text-decoration",'');
                break;    
             case 'line-through':
                $(".font_style").css("text-decoration",'');
                break;                      
         }
        };
    }










