var setIntervalId,setIntervalLoginId;
var timeread=2;
$(document).ready(function () {
        //var exdata=loaded(); //第一次加载数据
        
        if(!loaded()){
            return false;
        }
        setIntervalId=setInterval(read,timeread*1000);
        setIntervalLoginId = setInterval(login_info,3000);
         $("#send").click(function() {
        
             $(this).attr('disabled','disabled');
             setTimeout(function(){$("#send").attr('disabled',false);},2500)
             var str=get_in_data();
             if (!str) return false;
             witer_data(str);
        });
});

function witer_data(str){
            var sendLast=$(".userid:last").text();
            sendLast=sendLast.split('--');
            //alert(sendLast[0]);
            //return;
            var username=document.cookie.split(';');
            var username=username[0].split('=');
            var mydate=new Date();
            var nowTime=mydate.getHours()+':'+mydate.getMinutes()+':'+mydate.getSeconds();
            $.post("main.php?action=witer", { user: username[1], content:str,time:nowTime,lastuser: sendLast[0], lastdate:sendLast[1]},function(data) {
               if(data==5){
                    return ;
                }
               var obj = jQuery.parseJSON(data);
                 //$("#chat ul").html('');
                for (var i=0; i < obj.length; i++) {
                    if (obj[i]==0) {
                        break;
                    }
                    var user=obj[i].user;
                    var content=obj[i].content;
                    var user_text=user+'--'+obj[i].time+'--说:';
                    $("#chat ul").append('<li class="userid" style="color:blue;font-size:14px;">'+user_text+'</li><li>'+content+'</li>');
                   $("#chat").scrollTop(655350);
                    $("#intext").html('');
                    setTimeout(setInterval_start,2000);
                };
               
            } );
}
function read(){
      var sendLast=$(".userid:last").text();
      sendLast=sendLast.split('--');
      //alert(sendLast[1]);
      $.post("main.php?action=read", { lastuser: sendLast[0], lastdate:sendLast[1]},function(data){
            if(data==5){
                   $('html').click(function() {
                   document.title='web聊天室';
                   });
                   return ;
            }
            document.title='【您有新的信息】web聊天室';
            var obj = jQuery.parseJSON(data);
            for (var i=0; i < obj.length; i++) {
                var user=obj[i].user;
                var content=obj[i].content;
                var user_text=user+'--'+obj[i].time+'--说:';
                $("#chat ul").append('<li class="userid" style="color:blue;font-size:14px;">'+user_text+'</li><li>'+content+'</li>');
                $("#chat").scrollTop(655350);
            }
            })
       /*$.ajax({
           type: "POST",   
            url: "main.php?action=read",
            data: "lastdate="+sendLast[1],   
            success: function(data){
			if(data==5){
			       $('html').click(function() {
			       document.title='web聊天室';
			       });
                   return ;
			}
			document.title='【您有新的信息】web聊天室';
            var obj = jQuery.parseJSON(data);
            for (var i=0; i < obj.length; i++) {
                var user=obj[i].user;
                var content=obj[i].content;
                var user_text=user+'--'+obj[i].time+'--说:';
                $("#chat ul").append('<li class="userid" style="color:blue;font-size:14px;">'+user_text+'</li><li>'+content+'</li>');
                $("#chat").scrollTop(655350);
            }
            }
       });*/
}
//刚登陆时，加载数据等待
/**
 * 5.数据没有更新，不需要加载
 * 4.数据是空的。。。不需要加载
 */
function loaded(){
      $.ajax({
           type: "POST",   
            url: "main.php?action=load",   
            success: function(data){
            if(data==4){
                //alert(data);
                $("#chat").scrollTop(655350);
                return 0;
            }
            var obj = jQuery.parseJSON(data);
            $("#chat ul").html('');
            for (var i=0; i < obj.length; i++) {
                var user=obj[i].user;
                var content=obj[i].content;
                var user_text=user+'--'+obj[i].time+'--说:';
                $("#chat ul").append('<li class="userid" style="color:blue;font-size:14px;">'+user_text+'</li><li>'+content+'</li>');
                $("#chat").scrollTop(66666);
            }
            }
       });
       return 1;
}

//获取输入框数据，并处理
function get_in_data(){
    if ($("#intext").html()==''){
        alert('什么都没有。。。');
        return false;
    };
    clearInterval(setIntervalId);
    var i=$("#intext").hasClass('font_style');
    var str=html_change($("#intext").html());
    //alert(str);
    if(i){
        var font_size=$("input[name=font_size]").val();
        var color=$("input[name=font_color]").val();
        var font_weight=$(".font_style").css('font-weight');
        var font_styles=$(".font_style").css('font-style');
        var text_decoration=$(".font_style").css('text-decoration');
        str="<span style='font-size:"+font_size+"px; color:"+color+";font-weight:"+font_weight+";font-style:"+font_styles+";text-decoration:"+text_decoration+";'>"+str+"</span>";
    }
    return str;
}
//html字符转义
function html_change(str){
    $("#hide_text").html(str);
    //alert($("#hide_text").html());
       //这本来是表情地址替换，但后来发现多此一举
    // $("#hide_text img").each(function(index) {
       // var title = $(this).attr('title');
       // $(this).after(title);
    // });


    str=$("#hide_text").html();
    //alert(str);
    return str;
}
//登录信息更新
function login_info(){
    $.ajax({
           type: "POST",   
            url: "main.php?action=info",   
            success: function(data){
            if(data==5){
                //alert(data);
                return 0;
            }
            var obj = jQuery.parseJSON(data);
            $("#userlogin ul").html('');
            for (var i=0; i < obj.length; i++) {
                var user=obj[i].user;
                var name=obj[i].name;
                var time=obj[i].time;
                var type=obj[i].type;
                var face=obj[i].face;
                face=face.replace(/JPG/,"jpg");
                if(type==0){
                       var login_text=name+'('+user+')'+'→'+obj[i].time+'退出……:';
                       $("#userlogin ul").append('<li style="color:red;font-size:12px;">'+login_text+'</li>');
                }else{

                       var login_text=name+'('+user+')'+'→'+obj[i].time+'登陆……:';
                       $("#userlogin ul").append('<li style="color:green;font-size:12px;">'+login_text+'</li>');
                }
            }
            for(var i=obj.length-1; i >= 0; i--){
                var user=obj[i].user;
                var type=obj[i].type;
                var face=obj[i].face;
                var name=obj[i].name;
                face=face.replace(/JPG/,"jpg");
                  if(type==0){
                        $("#user span").each(function(index) {
                              if ($(this).attr('id')==user) {
                                  $(this).remove();
                              } 
                        });
                       /* if(online_list(user)){
                            
                        }*/
                 }else{
                     if (!online_list(user)) {
                         $("#user").append("<span id='"+user+"'><img src='http://localhost/test/webChat/face.php?filename="+face+"'/>"+name+"("+user+")</span>");
                     }
                 }
            }
            
            }
       });
}
function online_list(user){
     var type=0;
     $("#user span").each(function(index) {
        if ($(this).attr('id')==user) {
            type=1;
            return;
        } 
    })
    return type;
}
//定时执行
function setInterval_start(){
    setIntervalId=setInterval(read,timeread*1000);
}
