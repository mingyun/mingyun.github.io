<?php
/**
 * @author zeng
 * time:2012-3-28
 * QQ:1077040796
 * 
 */
define('CHAT', true);
include dirname(__FILE__).'/include/commen.inc.php';
global $mysql,$system;
$my_global=new myGlobal();

//是否登陆
if (!isset($_COOKIE['username'])) {
	$my_global->_location("非法操作！！！",'index.php');
}
/**
 * 退出
 */
if (isset($_GET['action'])&&$_GET['action']=='loginout') {
	$mysql->_query("update mc_user set mc_state=0 where mc_username='{$_COOKIE['username']}' limit 1  ");
	$row_out=$mysql->_fetch_array("select mc_minname,mc_face from mc_user where mc_username='{$_COOKIE['username']}' limit 1 ");
	$my_global->_unset_cookies();
	$login_time=date("H:i:s");
	$login_info=$login_time."§★ξ☆§0§★ξ☆§".$row_out['mc_minname']."§★ξ☆§".$_COOKIE['username']."§★ξ☆§".$row_out['mc_face']."|-ξ§ξ-|\n";
	$my_global->_file_witer($login_info, $system['online_file']);
	$mysql->_close();
	$my_global->_location("退出成功！！！", 'index.php');
}
//
if (isset($_GET['id'])) {
	$row=$mysql->_fetch_array("select mc_username from mc_user where mc_id='{$_GET['id']}' limit 1 ");
	if($row['mc_username']!=$_COOKIE['username']){
		$my_global->_unset_cookies();
		$my_global->_location('非法操作，请正常登陆！！！','index.php');
	}
}else{
		$my_global->_unset_cookies();
		$my_global->_location('非法操作，请正常登陆！！！','index.php');
}	
$result = $mysql->_query("select *  from mc_user where mc_state=1");



 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
<?php
	require ROOT_PATH.'include/header.inc.php'; 
?>
<script type="text/javascript" src="js/ajax.js"></script>
</head>
<body>
<div id="chat_main">
	<h2 id="title_h"><?php echo $_COOKIE['username'] ?>! 欢迎进入聊天室</h2>
	<div id="chat"><ul></ul></div>
	<div id="list">
		<dl>
			<dd id="notice">
			<h3>公告</h3>
			<p>这是一个简单的web聊天室.</p>
			</dd>
			<dd id="user">
			<?php
				while (!!$rows = $mysql->_fetch_array_list($result)) {
					$html=array();
					$html['name']=$rows['mc_username'];
					$html['minname']=$rows['mc_minname'];
					$html['face']=$rows['mc_face'];
					$html['face']=substr_replace($html['face'], 'jpg', -3);
					$html['email']=$rows['mc_email'];
					$html=$my_global->_html($html);
					$html['src']='http://localhost/test/webChat/face.php?filename='.$html['face'];
			?><span id="<?php echo $html['name']; ?>"><img title="<?php echo $html['minname']?>" src="<?php echo $html['src']?>" /><?php echo $html['minname'] ?>(<?php echo $html['name'] ?>)</span><?php }?>
			</dd>
			<dd id="userlogin">
			<ul></ul>
			</dd>
		</dl>
	</div>
	<div id="in"><div id="intext" contentEditable="true"></div></div>
	<div id="tool">
	<a href="?action=loginout" id="over">【退出】</a>
	<?php 
		$mysql->_free_result($result);
		include ROOT_PATH.'include/ubb.inc.php';
	?>
	</div>
</div>
<div id="hide_text"></div>
</body>
</html>